
from django.contrib import admin
from django.urls import path

from members import views
from rest_framework.views import *

urlpatterns = [
    path('', views.index,name='home'),
    path('service',views.service,name='service'),
    path('contact',views.contact,name='contact'),
    path('student/',views.post_student),
    path('update-student/<id>/',views.update_student),
    path('delete-student/<id>/',views.delete_student)
]



