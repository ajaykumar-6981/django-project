from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from rest_framework.decorators import api_view
from rest_framework.response import Response
from members import serializer
from .models import *
from .serializer import *

# Create your views here.
def index(request):
      mymember=Member.objects.all().values()
      data={
        'members': mymember,

      }
      print(data)
      return render(request,"home.html",data)
      # template = loader.get_template('home.html')
      # return HttpResponse(template.render())
#     return HttpResponse("Hello World")

@api_view(['GET'])
def service(request):
    student_objs=Member.objects.all()
    serializer=StudentSerializer(student_objs,many=True)

    # return Response({'status':200,'message':'Hello world for Django Api'})
    return Response({'status': 200, 'payload':serializer.data})

@api_view(['POST'])
def post_student(request):
    data=request.data
    print(data)
    serializer=StudentSerializer(data=request.data)

    if not serializer.is_valid():
        print(serializer.errors)
        return Response({'status':403,'payload':data,'message':'Error Occurred'})

    serializer.save()
    return Response({'status':200,'payload':data,'message':'data load successfully'})

@api_view(['POST'])
def update_student(request,id):
    try:
      student_obj=Member.objects.get(id=id)
      serializer=StudentSerializer(data=request.data)

    except Exception as e:
       print(e)
       return Response({'status':403,'message':'invalid id'})


@api_view(['DELETE'])
def delete_student(request, id):
    try:
        id=request.GET.get('id')
        student_obj=Member.objects.get(id=id)
        student_obj.delete()
        return Response({'status':4,'message':'invalid id'})
    except:
        pass
def contact(request):
    sum_both=0
    try:
       # n1=request.GET.get(['num1'])
       # n2=request.GET.get(['num2'])
       n1=int(request.POST.get('num1'))
       n2=int(request.POST.get('num2'))
       sum_both=n1+n2+sum_both;
       print(n1+n2)
    except:
        pass

    data={
        'title':'Home Page',
        'bdata': 'Welcome to world of Django',
        'clist':['PHP','Java','Django'],
        'sum_both':sum_both
    }

    # for x in data.values():
    #     print(x)
    return render(request,"contact.html",data)

