from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework import Response

# Create your views here.

# def service(request):
#      return render(request,'service.html')


@api_view()
def service(request):
    return render({'status':200,'messsage':'Hello from django framework'})
