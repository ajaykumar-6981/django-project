

from django.contrib import admin
from django.urls import path,include
from rest_framework.views import View

urlpatterns=[
    path('service',include('home.urls')),

]